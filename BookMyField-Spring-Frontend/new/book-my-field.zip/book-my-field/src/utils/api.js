import axios from "axios";

// ✅ Set API Base URL for consistency
const API_BASE_URL = "http://localhost:8080/api";

// ✅ Create Axios Instance
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    "Content-Type": "application/json",
    Accept: "application/json",
  },
  withCredentials: true, // ✅ Ensures cookies are sent if needed
});

// ✅ Attach JWT token to every request
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem("token");
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    } else {
      console.warn("🚨 No token found in localStorage. API request might fail.");
    }
    console.log("🔗 API Request:", config.method.toUpperCase(), config.url, "Headers:", config.headers);
    return config;
  },
  (error) => Promise.reject(error)
);

// ✅ Handle token expiry globally
api.interceptors.response.use(
  (response) => {
    console.log("✅ API Response:", response.status, response.data);
    return response;
  },
  (error) => {
    if (error.response && error.response.status === 401) {
      console.error("🚨 Token expired. Redirecting to login...");
      localStorage.removeItem("token"); // ✅ Remove expired token
      localStorage.removeItem("userRole");
      alert("Session expired. Please log in again."); // ✅ Inform user
      window.location.href = "/login"; // ✅ Redirect to login page
    }
    console.error("❌ API Error:", error.response ? error.response.data : error.message);
    return Promise.reject(error);
  }
);

export default api;
