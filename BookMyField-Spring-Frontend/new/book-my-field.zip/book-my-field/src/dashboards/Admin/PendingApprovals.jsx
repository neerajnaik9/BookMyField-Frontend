import React, { useEffect, useState } from "react";
import api from "../../utils/api";

const PendingApprovals = () => {
  const [fields, setFields] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchPendingFields = async () => {
      try {
        const response = await api.get("/admin/pending-fields");
        if (response.status === 200) {
          setFields(response.data);
        }
      } catch (err) {
        setError("Failed to fetch pending fields. Please try again.");
      } finally {
        setLoading(false);
      }
    };

    fetchPendingFields();
  }, []);

  const updateFieldStatus = (id, newStatus) => {
    setFields((prevFields) =>
      prevFields.map((field) =>
        field.id === id ? { ...field, status: newStatus } : field
      )
    );
  };

  const handleApprove = async (id) => {
    try {
      await api.put(`/admin/approve-field/${id}`);
      updateFieldStatus(id, "Approved");
      alert("✅ Field approved successfully!");
    } catch (err) {
      console.error("❌ Error approving field:", err);
      alert("🚨 Failed to approve the field. Try again.");
    }
  };

  const handleReject = async (id) => {
    try {
      await api.put(`/admin/reject-field/${id}`);
      updateFieldStatus(id, "Rejected");
      alert("❌ Field rejected successfully!");
    } catch (err) {
      console.error("❌ Error rejecting field:", err);
      alert("🚨 Failed to reject the field. Try again.");
    }
  };

  return (
    <div
      className="relative min-h-screen flex flex-col items-center justify-center bg-cover bg-center px-4 sm:px-6 lg:px-8"
      style={{ backgroundImage: "url('/images/trufGround.jpg')" }}
    >
      <div className="absolute inset-0 bg-black bg-opacity-60"></div>

      <div className="relative w-full max-w-6xl bg-white bg-opacity-90 backdrop-blur-md p-6 rounded-lg shadow-xl">
        <h1 className="text-3xl font-bold text-center mb-6 text-gray-900">
          Pending Approvals
        </h1>

        {loading ? (
          <p className="text-gray-500 text-center">Loading...</p>
        ) : error ? (
          <p className="text-red-500 text-center">{error}</p>
        ) : fields.length === 0 ? (
          <p className="text-gray-500 text-center">No pending approvals.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full border-collapse bg-white rounded-lg shadow-lg">
              <thead className="bg-blue-700 text-white">
                <tr>
                  <th className="p-4 text-left">Field Name</th>
                  <th className="p-4 text-left">Owner</th>
                  <th className="p-4 text-left">Location</th>
                  <th className="p-4 text-left">Description</th>
                  <th className="p-4 text-left">Timings</th>
                  <th className="p-4 text-left">Price (₹/hr)</th>
                  <th className="p-4 text-left">Category</th>
                  <th className="p-4 text-left">Image</th>
                  <th className="p-4 text-left">Status</th>
                  <th className="p-4 text-left">Actions</th>
                </tr>
              </thead>
              <tbody>
                {fields.map((field) => (
                  <tr
                    key={field.id}
                    className={`border-b ${
                      field.status === "Approved"
                        ? "bg-green-100"
                        : field.status === "Rejected"
                        ? "bg-red-100"
                        : "hover:bg-gray-100 transition duration-200"
                    }`}
                  >
                    <td className="p-4">{field.name}</td>
                    <td className="p-4">{field.owner.username}</td>
                    <td className="p-4">{field.location}</td>
                    <td className="p-4 truncate max-w-xs">{field.description}</td>
                    <td className="p-4">{field.timings.join(", ")}</td>
                    <td className="p-4 font-bold text-blue-600">₹{field.price}</td>
                    <td className="p-4">{field.category}</td>
                    <td className="p-4">
                      <img
                        src={`data:image/jpeg;base64,${field.base64Image}`}
                        alt={field.name}
                        className="w-24 h-24 object-cover rounded-lg shadow-md border"
                      />
                    </td>
                    <td className="p-4 font-bold text-gray-800">
                      {field.status === "Approved" ? (
                        <span className="text-green-600">✅ Approved</span>
                      ) : field.status === "Rejected" ? (
                        <span className="text-red-600">❌ Rejected</span>
                      ) : (
                        <span className="text-yellow-600">⏳ Pending</span>
                      )}
                    </td>
                    <td className="p-4 space-x-2">
                      {field.status === "Pending" && (
                        <>
                          <button
                            onClick={() => handleApprove(field.id)}
                            className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition duration-300"
                          >
                            Approve
                          </button>
                          <button
                            onClick={() => handleReject(field.id)}
                            className="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700 transition duration-300"
                          >
                            Reject
                          </button>
                        </>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default PendingApprovals;
