import React, { useEffect, useState } from "react";
import api from "../../utils/api";

const CustomersInfo = () => {
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchCustomers = async () => {
      try {
        const response = await api.get("/admin/customers");
        setCustomers(response.data);
      } catch (error) {
        setError("Failed to load customers.");
      } finally {
        setLoading(false);
      }
    };

    fetchCustomers();
  }, []);

  return (
    <div
      className="min-h-screen flex flex-col items-center justify-center bg-fixed bg-center bg-cover px-4 sm:px-6 lg:px-8 relative"
      style={{ backgroundImage: "url('/images/trufGround.jpg')" }}
    >
      <div className="absolute inset-0 bg-black bg-opacity-50"></div>
      <div className="relative w-full max-w-6xl bg-white bg-opacity-95 backdrop-blur-lg p-8 rounded-2xl shadow-2xl">
        <h1 className="text-4xl font-extrabold mb-6 text-center text-gray-900 tracking-wide">
          Registered Customers
        </h1>
        {loading ? (
          <p className="text-center text-lg text-gray-600">Loading...</p>
        ) : error ? (
          <p className="text-center text-red-500">{error}</p>
        ) : customers.length === 0 ? (
          <p className="text-center text-lg text-gray-600">No customers found.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full bg-white shadow-lg rounded-lg border border-gray-300">
              <thead className="bg-gradient-to-r from-blue-500 to-blue-700 text-white">
                <tr>
                  <th className="p-4 text-left">Username</th>
                  <th className="p-4 text-left">Email</th>
                  <th className="p-4 text-left">Mobile</th>
                  <th className="p-4 text-left">Customer Name</th>
                </tr>
              </thead>
              <tbody>
                {customers.map((customer, index) => (
                  <tr
                    key={index}
                    className="border-b border-gray-300 hover:bg-blue-100 transition duration-300"
                  >
                    <td className="p-4 text-gray-800">{customer.username}</td>
                    <td className="p-4 text-gray-800">{customer.email}</td>
                    <td className="p-4 text-gray-800">{customer.mobile}</td>
                    <td className="p-4 text-gray-800">{customer.customerName}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default CustomersInfo;