import React, { useEffect, useState } from "react";
import api from "../../utils/api"; // Import Axios instance
import { useNavigate } from "react-router-dom"; // ✅ Import useNavigate

const MyFields = () => {
  const [fields, setFields] = useState([]);
  const [error, setError] = useState("");
  const [imageUrls, setImageUrls] = useState({}); // Store image URLs
  const navigate = useNavigate(); // ✅ Define navigate function

  // Fetch fields owned by the current user
  useEffect(() => {
    const fetchFields = async () => {
      try {
        const response = await api.get("/fields/my-fields");
        if (response.status === 200) {
          setFields(response.data);
          fetchImages(response.data);
        }
      } catch (error) {
        console.error("Error fetching fields:", error);
        setError("Failed to fetch fields. Please try again.");
      }
    };

    fetchFields();
  }, []);

  // Fetch images and store in state
  const fetchImages = async (fieldsData) => {
    const urls = {};
    for (const field of fieldsData) {
      try {
        const response = await api.get(`/fields/${field.id}/image`);
        if (response.status === 200) {
          urls[field.id] = response.data; // ✅ Base64 string is already prefixed correctly
        } else {
          urls[field.id] = "/images/default_field.jpg";
        }
      } catch (error) {
        console.error(`Error fetching image for field ${field.id}:`, error);
        urls[field.id] = "/images/default_field.jpg";
      }
    }
    setImageUrls(urls);
  };

  // Delete a field by id
  const handleDelete = async (id) => {
    try {
      await api.delete(`/fields/${id}`);
      setFields(fields.filter((field) => field.id !== id));
      alert("Field deleted successfully!");
    } catch (error) {
      console.error("Error deleting field:", error);
      alert("Failed to delete field. Please try again.");
    }
  };

  // ✅ Edit a field
  const handleEdit = (id) => {
    navigate(`/field-owner/edit-field/${id}`); // ✅ Navigate to Edit Page
  };

  return (
    <div
      className="min-h-screen flex flex-col items-center bg-cover bg-center py-8"
      style={{ backgroundImage: "url('/images/my_fields_background.jpg')" }}
    >
      <div className="bg-white bg-opacity-90 rounded-lg shadow-lg p-6 w-11/12 max-w-4xl">
        <h1 className="text-3xl font-bold text-center mb-6 text-gray-800">
          My Fields
        </h1>
        {error && <p className="text-red-500 text-center mb-4">{error}</p>}
        {fields.length === 0 ? (
          <p className="text-gray-600 text-center">No fields added yet.</p>
        ) : (
          <table className="table-auto w-full border-collapse border border-gray-300">
            <thead>
              <tr className="bg-gradient-to-r from-blue-500 to-green-500 text-white">
                <th className="p-4 text-left">Field Image</th>
                <th className="p-4 text-left">Field Name</th>
                <th className="p-4 text-left">Location</th>
                <th className="p-4 text-left">Price</th>
                <th className="p-4 text-left">Actions</th>
              </tr>
            </thead>
            <tbody>
              {fields.map((field) => (
                <tr
                  key={field.id}
                  className="even:bg-gray-50 odd:bg-white hover:bg-gray-100 transition duration-200"
                >
                  {/* ✅ Display Base64 image */}
                  <td className="p-4 border border-gray-300">
                    <img
                      src={imageUrls[field.id] || "/images/default_field.jpg"}
                      alt={field.name}
                      className="w-20 h-20 object-cover rounded-lg shadow-md"
                    />
                  </td>
                  <td className="p-4 border border-gray-300 font-medium text-gray-700">
                    {field.name}
                  </td>
                  <td className="p-4 border border-gray-300 text-gray-600">
                    {field.location}
                  </td>
                  <td className="p-4 border border-gray-300 text-gray-600">
                    ₹{field.price}
                  </td>
                  <td className="p-4 border border-gray-300">
                    <button
                      onClick={() => handleEdit(field.id)}
                      className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition duration-300 mr-2"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => handleDelete(field.id)}
                      className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 transition duration-300"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default MyFields;
