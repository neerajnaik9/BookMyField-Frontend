import React, { useEffect, useState } from "react";
import api from "../../utils/api"; // Import the Axios instance

const AdminApproval = () => {
  const [fields, setFields] = useState([]);
  const [error, setError] = useState("");

  // ✅ Fetch all approvals (Approved, Rejected, Pending) for the Field Owner
  useEffect(() => {
    const fetchApprovals = async () => {
      try {
        const response = await api.get("/fields/my-approvals"); // ✅ Correct API
        if (response.status === 200) {
          setFields(response.data);
        }
      } catch (error) {
        console.error("❌ Error fetching approvals:", error);
        setError("Failed to fetch approvals.");
      }
    };

    fetchApprovals();
  }, []);

  return (
    <div
      className="min-h-screen flex flex-col items-center bg-cover bg-center py-8"
      style={{ backgroundImage: "url('/images/admin_approval_background.jpg')" }}
    >
      <div className="bg-white bg-opacity-60 backdrop-blur-md rounded-lg shadow-lg p-6 w-11/12 max-w-4xl">
        <h1 className="text-3xl font-bold text-center mb-6 text-gray-800">
          My Approvals & Status Updates
        </h1>
        {error && <p className="text-red-500 text-center mb-4">{error}</p>}
        {fields.length === 0 ? (
          <p className="text-gray-600 text-center">No approvals found.</p>
        ) : (
          <table className="table-auto w-full border-collapse border border-gray-300">
            <thead>
              <tr className="bg-gradient-to-r from-blue-500 to-green-500 text-white">
                <th className="p-4 text-left">Field Name</th>
                <th className="p-4 text-left">Location</th>
                <th className="p-4 text-left">Price (₹/hr)</th>
                <th className="p-4 text-left">Category</th>
                <th className="p-4 text-left">Status</th>
              </tr>
            </thead>
            <tbody>
              {fields.map((field) => (
                <tr
                  key={field.id}
                  className={`even:bg-gray-50 odd:bg-white hover:bg-gray-100 transition duration-200 ${
                    field.status === "Approved"
                      ? "bg-green-100"
                      : field.status === "Rejected"
                      ? "bg-red-100"
                      : "bg-yellow-100"
                  }`}
                >
                  <td className="p-4 border border-gray-300 font-medium text-gray-700">
                    {field.name}
                  </td>
                  <td className="p-4 border border-gray-300 text-gray-600">
                    {field.location}
                  </td>
                  <td className="p-4 border border-gray-300 text-gray-600 font-bold text-blue-700">
                    ₹{field.price}
                  </td>
                  <td className="p-4 border border-gray-300 text-gray-600">
                    {field.category}
                  </td>
                  <td className="p-4 border border-gray-300 text-lg font-semibold">
                    {field.status === "Approved" ? (
                      <span className="text-green-700">✅ Approved</span>
                    ) : field.status === "Rejected" ? (
                      <span className="text-red-700">❌ Rejected</span>
                    ) : (
                      <span className="text-yellow-700">⏳ Pending</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default AdminApproval;
