import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import api from "../../utils/api"; // Import Axios instance

const EditField = () => {
  const { id } = useParams(); // ✅ Get field ID from URL
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    name: "",
    location: "",
    description: "",
    timings: "",
    price: "",
    category: "Cricket",
    base64Image: "",
    status: "Pending",
  });

  const [errors, setErrors] = useState({});
  const [successMessage, setSuccessMessage] = useState("");
  const [loading, setLoading] = useState(true);

  // ✅ Fetch existing field details
  useEffect(() => {
    const fetchFieldDetails = async () => {
      try {
        const response = await api.get(`/fields/${id}`);
        if (response.status === 200) {
          const field = response.data;
          setFormData({
            name: field.name || "",
            location: field.location || "",
            description: field.description || "",
            timings: field.timings ? field.timings.join(", ") : "",
            price: field.price || "",
            category: field.category || "Cricket",
            base64Image: field.base64Image ? `data:image/jpeg;base64,${field.base64Image}` : "",
            status: field.status || "Pending",
          });
        }
      } catch (error) {
        console.error("Error fetching field details:", error);
        setErrors({ fetch: "Failed to load field details." });
      } finally {
        setLoading(false);
      }
    };

    fetchFieldDetails();
  }, [id]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result; // ✅ Keep full Base64
        setFormData({ ...formData, base64Image: base64String }); // ✅ Do not remove metadata
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const updatedField = {
        ...formData,
        timings: formData.timings.split(",").map((time) => time.trim()), // Convert timings to an array
      };

      const response = await api.put(`/fields/${id}`, updatedField);
      if (response.status === 200) {
        setSuccessMessage("✅ Field updated successfully!");
        setTimeout(() => navigate("/field-owner/my-fields"), 2000);
      }
    } catch (error) {
      console.error("Error updating field:", error);
      setErrors({ submit: "🚨 Failed to update field. Please try again." });
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-cover bg-center"
      style={{ backgroundImage: "url('/images/add_field_background.jpg')" }}
    >
      <div className="bg-white bg-opacity-90 p-8 rounded-lg shadow-lg max-w-2xl w-full">
        <h1 className="text-3xl font-bold text-primary mb-6 text-center">
          Edit Field
        </h1>
        {errors.fetch && <p className="text-red-500 text-center">{errors.fetch}</p>}
        
        {loading ? (
          <p className="text-gray-600 text-center">Loading field details...</p>
        ) : (
          <form onSubmit={handleSubmit}>
            {/* Field Name */}
            <div className="mb-4">
              <label className="block mb-2 font-bold">Field Name</label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-primary"
                required
              />
            </div>

            {/* Location */}
            <div className="mb-4">
              <label className="block mb-2 font-bold">Location</label>
              <input
                type="text"
                name="location"
                value={formData.location}
                onChange={handleChange}
                className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-primary"
                required
              />
            </div>

            {/* Description */}
            <div className="mb-4">
              <label className="block mb-2 font-bold">Description</label>
              <textarea
                name="description"
                value={formData.description}
                onChange={handleChange}
                className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-primary"
                rows="4"
                required
              ></textarea>
            </div>

            {/* Price */}
            <div className="mb-4">
              <label className="block mb-2 font-bold">Price (₹ per hour)</label>
              <input
                type="number"
                name="price"
                value={formData.price}
                onChange={handleChange}
                className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-primary"
                required
              />
            </div>

            {/* Image Upload */}
            <div className="mb-4">
              <label className="block mb-2 font-bold">Upload Image</label>
              <input
                type="file"
                accept="image/*"
                onChange={handleImageChange}
                className="w-full px-4 py-2 border rounded-lg"
              />
              {formData.base64Image && (
                <div className="mt-4">
                  <img
                    src={formData.base64Image}
                    alt="Preview"
                    className="w-full h-40 object-cover rounded-lg shadow-md"
                  />
                </div>
              )}
            </div>

            {/* Submit Button */}
            <div className="mt-6">
              <button
                type="submit"
                className="w-full bg-blue-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-blue-700 transition duration-300 shadow-lg"
              >
                Update Field
              </button>
            </div>
            {errors.submit && <p className="text-red-500 text-center mt-2">{errors.submit}</p>}
            {successMessage && <p className="text-green-500 text-center mt-2">{successMessage}</p>}
          </form>
        )}
      </div>
    </div>
  );
};

export default EditField;
