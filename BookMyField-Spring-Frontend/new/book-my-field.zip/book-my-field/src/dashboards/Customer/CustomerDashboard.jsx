import React from "react";
import { useNavigate } from "react-router-dom";

const CustomerDashboard = () => {
  const navigate = useNavigate();

  const categories = [
    { name: "Cricket", image: "/images/cricket.jpg" },
    { name: "Football", image: "/images/football.jpg" },
    { name: "Basketball", image: "/images/basketball.jpg" },
    { name: "Badminton", image: "/images/badminton.jpg" },
  ];

  return (
    <div className="relative min-h-screen flex flex-col items-center justify-center bg-cover bg-center px-4 sm:px-6 lg:px-8"
         style={{ backgroundImage: "url('/images/customerdashboard.jpg')" }}>
      <div className="absolute inset-0 bg-black bg-opacity-50"></div>

      <div className="relative w-full max-w-6xl text-center text-white">
        <h1 className="text-5xl font-extrabold mb-6 tracking-wide">Explore Sports Categories</h1>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
          {categories.map((category, index) => (
            <div key={index} className="p-6 bg-white bg-opacity-90 rounded-lg shadow-lg text-center flex flex-col items-center transform transition duration-300 hover:scale-110 hover:shadow-xl hover:bg-opacity-100">
              <img src={category.image} alt={category.name} className="w-full h-40 object-cover rounded-md mb-4" />
              <h2 className="font-bold text-xl text-gray-900">{category.name}</h2>
              <button className="mt-4 bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition duration-300"
                onClick={() => navigate(`/turfs`, { state: { category: category.name } })}
              >
                Book Now
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default CustomerDashboard;
