import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../../utils/api"; // ✅ Import Axios instance for API calls

const FieldListings = () => {
  const [fields, setFields] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    fetchFields();
  }, []);

  // ✅ Fetch all available turfs from backend
  const fetchFields = async () => {
    try {
      const response = await api.get("/customer/fields");
      setFields(response.data);
      console.log("✅ Fetched fields:", response.data);
    } catch (error) {
      console.error("❌ Error fetching fields:", error);
    } finally {
      setLoading(false);
    }
  };

  // ✅ Handle search input change
  const handleSearch = (e) => {
    setSearchQuery(e.target.value);
  };

  // ✅ Handle "Book Now" click
  const handleBookNow = async (field) => {
    const userRole = localStorage.getItem("userRole");
    if (!userRole || userRole !== "customer") {
        alert("🚨 Please log in as a customer to proceed with booking.");
        navigate("/login");
        return;
    }

    let selectedDate = prompt("Enter booking date (YYYY-MM-DD):");
    if (!selectedDate || new Date(selectedDate) < new Date()) {
        alert("🚨 Invalid date! You cannot book for a past date.");
        return;
    }

    let startTime = prompt("Enter Start Time (HH:mm) [e.g., 09:00]:");
    let endTime = prompt("Enter End Time (HH:mm) [e.g., 10:00]:");

    if (!startTime || !endTime || startTime >= endTime) {
        alert("🚨 Invalid time selection! Ensure start time is before end time.");
        return;
    }

    try {
        const token = localStorage.getItem("token");
        const headers = { Authorization: `Bearer ${token}` };

        console.log("🔍 Checking slot availability:", { selectedDate, startTime, endTime });

        // ✅ Step 1: Check availability
        const availabilityResponse = await api.post(
            `/customer/check-availability/${field.id}`,
            null,
            { params: { date: selectedDate, startTime, endTime }, headers }
        );

        if (!availabilityResponse.data.available) {
            alert("🚨 This time slot is not available. Please choose a different slot.");
            return;
        }

        // ✅ Step 2: Book the field before proceeding to payment
        const bookingResponse = await api.post(
            `/customer/book-field/${field.id}`,
            { bookingDate: selectedDate, startTime, endTime },
            { headers }
        );

        console.log("✅ Booking Response:", bookingResponse.data);

        if (bookingResponse.data.bookingId) {
            localStorage.setItem("bookingId", bookingResponse.data.bookingId); // ✅ Store in localStorage
        }

        if (bookingResponse.data.message.includes("successful") && bookingResponse.data.bookingId) {
            navigate("/payment", {
                state: {
                    turf: field,
                    date: selectedDate,
                    startTime,
                    endTime,
                    bookingId: bookingResponse.data.bookingId, // ✅ Pass bookingId
                },
            });
        } else {
            alert("❌ Error: Booking failed or booking ID is missing. Please try again.");
        }
    } catch (error) {
        alert("❌ Error checking availability. Please try again.");
        console.error("🚨 API Error:", error.response ? error.response.data : error);
    }
};


  // ✅ Filter fields based on search query
  const filteredFields = fields.filter((field) =>
    field.location.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div
      className="relative min-h-screen flex flex-col items-center justify-center bg-cover bg-center px-4 sm:px-6 lg:px-8"
      style={{ backgroundImage: "url('/images/field1.jpg')" }}
    >
      <div className="absolute inset-0 bg-black bg-opacity-50"></div>
      <div className="relative w-full max-w-6xl text-white py-8">
        <div className="flex flex-col md:flex-row items-center justify-between mb-6">
          <h1 className="text-3xl font-bold text-center md:text-left">
            Available Turfs
          </h1>
          <div className="w-full md:w-1/3 mt-4 md:mt-0">
            <input
              type="text"
              value={searchQuery}
              onChange={handleSearch}
              placeholder="Search by city..."
              className="w-full p-3 border rounded-md text-gray-800 text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
          </div>
        </div>

        {loading ? (
          <p className="text-center text-lg text-white">Loading fields...</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            {filteredFields.length > 0 ? (
              filteredFields.map((field) => (
                <div
                  key={field.id}
                  className="p-6 bg-white bg-opacity-90 backdrop-blur-md rounded-lg shadow-md text-center flex flex-col items-center transform transition duration-300 hover:scale-105 hover:shadow-lg"
                >
                  <img
                    src={`http://localhost:8080/uploads/${field.image}`}
                    alt={field.name}
                    className="w-full h-40 object-cover rounded-md mb-4"
                  />

                  <h2 className="text-lg font-bold text-gray-900">{field.name}</h2>
                  <p className="text-gray-600">Location: {field.location}</p>
                  <p className="text-lg font-bold mt-2 text-blue-600">
                    ₹{field.price} per hour
                  </p>
                  <button
                    onClick={() => handleBookNow(field)}
                    className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition duration-300 mt-4"
                  >
                    Book Now
                  </button>
                </div>
              ))
            ) : (
              <p className="text-gray-300 text-center">
                No turfs found for the search query.
              </p>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default FieldListings;
