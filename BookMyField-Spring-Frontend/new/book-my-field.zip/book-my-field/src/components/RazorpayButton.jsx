import React from "react";
import { useNavigate } from "react-router-dom";
import api from "../utils/api"; // ✅ Import Axios instance for API calls

const RazorpayButton = ({ amount, bookingId, isAvailable }) => {
  const navigate = useNavigate();

  const handlePayment = async (paymentMethod) => {
    if (!isAvailable || !bookingId) {
        alert("🚨 Field is no longer available or booking ID is missing.");
        return;
    }

    try {
        const headers = { Authorization: `Bearer ${localStorage.getItem("token")}` };
        const { data } = await api.post(
            "/payment/create-order",
            { amount: amount * 100, currency: "INR", bookingId },
            { headers }
        );

        const options = {
            key: "rzp_test_IIva3ASPmbLTbc", // Replace with your Razorpay key
            amount: data.amount,
            order_id: data.orderId,
            handler: async function (response) {
                alert(`✅ Payment successful! Payment ID: ${response.razorpay_payment_id}`);
                
                await api.post(
                    "/payment/confirm",
                    { bookingId, paymentId: response.razorpay_payment_id },
                    { headers }
                );

                navigate("/customer/booking-history");
            },
            prefill: {
                name: "Your Name",
                email: "yourname@example.com",
                contact: "9999999999",
            },
            theme: {
                color: "#3399cc",
            },
        };

        const razorpay = new window.Razorpay(options);
        razorpay.open();
    } catch (error) {
        alert("❌ Error processing payment.");
    }
  };

  return (
    <button
      onClick={handlePayment}
      className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 transition duration-300"
    >
      Pay Now
    </button>
  );
};

export default RazorpayButton;
