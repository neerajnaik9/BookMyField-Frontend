import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import api from "../utils/api"; // ✅ Ensure API instance is used

const TurfGroundList = () => {
  const { sport } = useParams(); // ✅ Get category from URL
  const [fields, setFields] = useState([]);
  const [locationInput, setLocationInput] = useState("");
  const [selectedField, setSelectedField] = useState(null);
  const [selectedDate, setSelectedDate] = useState("");
  const [selectedTime, setSelectedTime] = useState("");
  const [isAvailable, setIsAvailable] = useState(null);
  const [invalidDate, setInvalidDate] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    fetchFieldsByCategory();
  }, [sport]);

  // ✅ Fetch fields by category from backend
  const fetchFieldsByCategory = async () => {
    try {
      const response = await api.get(`/api/customer/fields/category/${sport}`);
      setFields(response.data);
      console.log(`✅ Fetched ${sport} fields:`, response.data);
    } catch (error) {
      console.error(`❌ Error fetching ${sport} fields:`, error);
    }
  };

  const handleBookNow = (field) => {
    const userRole = localStorage.getItem("userRole");
    if (!userRole || userRole !== "customer") {
      alert("🚨 Please log in as a customer to proceed with booking.");
      navigate("/login");
      return;
    }

    setSelectedField(field);
    setIsAvailable(null);
    setSelectedDate("");
    setSelectedTime("");
  };

  // ✅ Check slot availability
  const checkAvailability = async () => {
    if (!selectedDate) {
      alert("🚨 Please select a booking date.");
      return;
    }

    if (new Date(selectedDate) < new Date()) {
      setInvalidDate(true);
      return;
    } else {
      setInvalidDate(false);
    }

    if (!selectedTime) {
      alert("🚨 Please select a time slot.");
      return;
    }

    const endTime = `${String(parseInt(selectedTime.split(":")[0]) + 1).padStart(2, "0")}:${selectedTime.split(":")[1]}`; // ✅ Ensure proper format

    try {
      console.log(`🔍 Checking availability for ${selectedField.name}...`);
      const response = await api.post(
        `/api/customer/check-availability/${selectedField.id}`,
        null,
        { params: { date: selectedDate, startTime: selectedTime, endTime } }
      );

      setIsAvailable(response.data.available);
    } catch (error) {
      console.error("❌ Error checking availability:", error);
      alert("❌ Error checking availability. Please try again.");
    }
  };

  // ✅ Proceed to payment after booking
  const proceedToPayment = async () => {
    try {
      const token = localStorage.getItem("token");
      const headers = { Authorization: `Bearer ${token}` };

      console.log("✅ Booking field before payment...");
      const response = await api.post(
        `/api/customer/book-field/${selectedField.id}`,
        { bookingDate: selectedDate, startTime: selectedTime, endTime: `${parseInt(selectedTime.split(":")[0]) + 1}:00` },
        { headers }
      );

      if (response.data.bookingId) {
        localStorage.setItem("bookingId", response.data.bookingId);
        navigate("/payment", {
          state: {
            turf: selectedField,
            date: selectedDate,
            startTime: selectedTime,
            endTime: `${parseInt(selectedTime.split(":")[0]) + 1}:00`,
            bookingId: response.data.bookingId,
          },
        });
      } else {
        alert("❌ Booking failed. Please try again.");
      }
    } catch (error) {
      console.error("❌ Error booking field:", error);
      alert("❌ Error booking field. Please try again.");
    }
  };

  const closeBookingModal = () => {
    setSelectedField(null);
    setSelectedDate("");
    setSelectedTime("");
    setIsAvailable(null);
    setInvalidDate(false);
  };

  return (
    <div className="relative min-h-screen flex flex-col items-center justify-center bg-cover bg-center px-4 sm:px-6 lg:px-8"
         style={{ backgroundImage: "url('/images/trufGround.jpg')" }}>
      <div className="relative w-full max-w-6xl text-white py-8">
        <button onClick={() => navigate(-1)} className="absolute top-4 left-4 bg-gray-700 text-white px-4 py-2 rounded-md">
          ← Back
        </button>

        <h1 className="text-3xl font-bold text-center mb-6">{sport} Turfs</h1>

        <div className="flex justify-end mb-6 px-4">
          <div className="w-64">
            <label className="block text-white font-bold mb-1">Location</label>
            <input
              type="text"
              placeholder="Enter Location"
              className="p-2 border rounded-md text-black w-full"
              value={locationInput}
              onChange={(e) => setLocationInput(e.target.value)}
            />
          </div>
        </div>

        {fields.length === 0 ? (
          <p className="text-gray-300 text-center">No approved turfs available in this category.</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            {fields.map((field) => (
              <div key={field.id} className="p-6 bg-white bg-opacity-20 backdrop-blur-md rounded-lg shadow-md text-center flex flex-col items-center transform transition duration-300 hover:scale-105 hover:shadow-lg text-white">
                <img src={`http://localhost:8080/uploads/${field.image}`} alt={field.name} className="w-full h-40 object-cover rounded-md mb-4" />
                <p className="font-bold text-yellow-300">🏟️ {field.name}</p>
                <p className="text-yellow-300">📍 {field.location}</p>
                <p className="text-yellow-300">💰 ₹{field.price} per hour</p>

                <button onClick={() => handleBookNow(field)} className="mt-4 bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition duration-300">
                  Book Now
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {selectedField && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
          <div className="bg-white p-6 rounded-lg shadow-lg w-96 text-center text-black">
            <h2 className="text-xl font-bold mb-4">Select Date & Time</h2>
            <input type="date" className="border p-2 w-full mb-4" value={selectedDate} onChange={(e) => setSelectedDate(e.target.value)} />
            <input type="time" className="border p-2 w-full mb-4" value={selectedTime} onChange={(e) => setSelectedTime(e.target.value)} />

            <button onClick={checkAvailability} className="bg-blue-600 text-white px-4 py-2 rounded-md w-full">
              Check Availability
            </button>

            {isAvailable && (
              <button onClick={proceedToPayment} className="mt-4 bg-green-600 text-white px-4 py-2 rounded-md w-full">
                Confirm & Proceed to Payment
              </button>
            )}

            <button onClick={closeBookingModal} className="mt-4 bg-red-600 text-white px-4 py-2 rounded-md w-full">
              Back
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default TurfGroundList;
