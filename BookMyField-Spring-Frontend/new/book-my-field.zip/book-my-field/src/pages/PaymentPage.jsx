import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import api from "../utils/api"; // ✅ Import Axios instance for API calls

const PaymentPage = () => {
  const { state } = useLocation();
  const navigate = useNavigate();
  const turf = state?.turf;
  const [loading, setLoading] = useState(false);
  const [availabilityChecked, setAvailabilityChecked] = useState(false);
  const [isAvailable, setIsAvailable] = useState(false);
  const [bookingId, setBookingId] = useState(state?.bookingId || null);

  useEffect(() => {
    const userRole = localStorage.getItem("userRole");
    if (!userRole || userRole !== "customer") {
      alert("🚨 Please log in as a customer to access the payment page.");
      navigate("/login");
    }

    // ✅ Fetch bookingId from localStorage if missing
    const storedBookingId = localStorage.getItem("bookingId");
    if (!bookingId && storedBookingId) {
      setBookingId(storedBookingId);
    }
  }, [navigate, bookingId]);

  useEffect(() => {
    if (!bookingId) {
      alert("🚨 Booking not found. Redirecting...");
      navigate("/customer/field-listings");
    }
  }, [bookingId, navigate]);

  // ✅ Load Razorpay script only once
  const loadRazorpayScript = async () => {
    if (document.querySelector('script[src="https://checkout.razorpay.com/v1/checkout.js"]')) {
      return true;
    }

    return new Promise((resolve) => {
      const script = document.createElement("script");
      script.src = "https://checkout.razorpay.com/v1/checkout.js";
      script.onload = () => resolve(true);
      script.onerror = () => resolve(false);
      document.body.appendChild(script);
    });
  };

  // ✅ Check field availability before proceeding
  const checkAvailability = async () => {
    try {
      const { date, startTime, endTime } = state;
      const headers = { Authorization: `Bearer ${localStorage.getItem("token")}` };

      console.log("🔍 Checking slot availability:", { date, startTime, endTime });

      const response = await api.post(
        `/customer/check-availability/${turf.id}`,
        null,
        { params: { date, startTime, endTime }, headers }
      );

      console.log("✅ Availability Response:", response.data);

      setAvailabilityChecked(true);
      setIsAvailable(response.data.available);

      if (!response.data.available) {
        alert("🚨 This slot is no longer available. Please choose another.");
        navigate("/customer/field-listings");
      }
    } catch (error) {
      console.error("❌ Availability check failed:", error);
      setAvailabilityChecked(true);
      setIsAvailable(false);
    }
  };
  useEffect(() => {
    if (!availabilityChecked) {
      checkAvailability();
    }
  }, [checkAvailability, availabilityChecked]); // ✅ Ensure useEffect is properly handling dependencies

  // ✅ Handle payment process
  const handlePayment = async (paymentMethod) => {
    if (!isAvailable || !bookingId) {
      alert("🚨 Field is no longer available or booking ID is missing. Please try again.");
      return;
    }

    setLoading(true);

    const scriptLoaded = await loadRazorpayScript();
    if (!scriptLoaded) {
      alert("❌ Failed to load Razorpay SDK. Please try again later.");
      setLoading(false);
      return;
    }

    try {
      const { date, startTime, endTime } = state;
      const headers = { Authorization: `Bearer ${localStorage.getItem("token")}` };

      console.log("💰 Initiating payment...");

      // ✅ Create Razorpay order
      const { data } = await api.post(
        "/payment/create-order",
        { 
          amount: parseFloat(turf.price) * 100, // ✅ Ensure amount is sent as a float
          currency: "INR", 
          bookingId, 
          date, 
          startTime, 
          endTime 
        },
        { headers }
      );
      

      console.log("✅ Payment Order Response:", data);

      const options = {
        key: process.env.REACT_APP_RAZORPAY_KEY || "rzp_test_IIva3ASPmbLTbc",
        amount: data.amount,
        currency: "INR",
        name: "BookMyField",
        description: `Booking for ${turf.name}`,
        image: `http://localhost:8080/uploads/${turf.image}`,
        order_id: data.orderId,
        handler: async function (response) {
          alert(`✅ Payment successful! Payment ID: ${response.razorpay_payment_id}`);

          console.log("✅ Payment Success Response:", response);

          await api.post(
            "/payment/confirm",
            { bookingId, paymentId: response.razorpay_payment_id },
            { headers }
          );

          navigate("/customer/booking-history");
        },
        prefill: {
          name: localStorage.getItem("username") || "Guest",
          email: "user@example.com",
          contact: "9999999999",
        },
        theme: {
          color: paymentMethod === "Google Pay" ? "#4285F4" : "#6F32BE",
        },
      };

      const razorpay = new window.Razorpay(options);
      razorpay.open();
    } catch (error) {
      alert("❌ Error processing payment. Please try again.");
      console.error("Payment Error:", error);
    }

    setLoading(false);
  };

  return (
    <div className="relative min-h-screen flex flex-col items-center justify-center bg-cover bg-center px-4 sm:px-6 lg:px-8"
      style={{ backgroundImage: "url('/images/payment.jpg')" }}>
      <div className="absolute inset-0 bg-black bg-opacity-50"></div>
      <div className="relative w-full max-w-5xl text-white py-8 text-center">
        <h1 className="text-3xl font-bold mb-6">Payment Page</h1>
        <div className="bg-white bg-opacity-90 backdrop-blur-md p-6 rounded-lg shadow-md max-w-md mx-auto text-gray-900">
          <img
            src={`http://localhost:8080/uploads/${turf.image}`}
            alt={turf.name}
            className="w-full h-60 object-cover rounded mb-4"
          />
          <h2 className="text-xl font-bold">{turf.name}</h2>
          <p className="text-gray-600 mt-2">{turf.location}</p>
          <p className="mt-2">{turf.description}</p>
          <p className="text-lg font-bold mt-4 text-blue-600">₹{turf.price} per hour</p>
        </div>
        <div className="bg-gray-100 p-6 rounded-lg shadow-md mt-8 max-w-md mx-auto">
          <h2 className="text-lg font-bold mb-4 text-gray-900">Choose a Payment Method</h2>
          <button onClick={() => handlePayment("Google Pay")} className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition duration-300" disabled={loading}>
            {loading ? "Processing..." : "Pay with Google Pay"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default PaymentPage;
